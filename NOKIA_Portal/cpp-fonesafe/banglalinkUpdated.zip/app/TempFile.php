<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TempFile extends Model
{
    //
}

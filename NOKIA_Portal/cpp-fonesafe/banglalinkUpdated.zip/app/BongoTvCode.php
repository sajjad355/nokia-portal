<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BongoTvCode extends Model
{
    protected $fillable = [
        'bongo_tv_code', 'status'
    ];
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ServicePoint extends Model
{
    //
}

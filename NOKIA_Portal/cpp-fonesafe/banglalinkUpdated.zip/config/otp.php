<?php

return [
    /*
     * This is the default number of digits for all your calls.
     */
    'digits' => 4,

    /*
     * This is the default expiry time for all your calls.
     */
    'expiry' => 3,
];
